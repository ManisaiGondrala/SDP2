from django.contrib import admin
from django.urls import path, include

from . import views

# . represents current directory

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",include("demoapp.urls")),
]

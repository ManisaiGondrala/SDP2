from django.shortcuts import render
from django.shortcuts import redirect, render
from django.db.models import Q
from .models import Admin, Employee, Product
from .forms import AdminLoginForm,EmployeeRegistrationForm,ProductForm

def homepage(request):
    return render(request,"index.html")
def registration(request):
    form = EmployeeRegistrationForm()
    if request.method == "POST":
        formdata = EmployeeRegistrationForm(request.POST)
        if formdata.is_valid():
            formdata.save()
            msg="Employee Registered Successfully"
            return render(request, "login.html", {"empform": form,"msg":msg})
        else:
            msg = "Failed to Register Employee"
            return render(request, "registration.html", {"empform": form, "msg": msg})
    return render(request,"registration.html",{"empform":form})


def indexpage(request):
    return render(request,"index.html")

def registrationpage(request):
    return render(request,"registration.html")

def loginpage(request):
    return render(request,"login.html")
def aboutpage(request):
    return render(request,"about.html")

def contactuspage(request):
    return render(request,"contactus.html")

def userfunction(request):
    return render(request,"userhome.html")
def orderfunction(request):
    return render(request,"order.html")
def checkemplogin(request):
    uname = request.POST["eusername"]
    pwd = request.POST["epassword"]

    flag = Employee.objects.filter(Q(username=uname) & Q(password=pwd))

    print(flag)

    if flag:
        emp = Employee.objects.get(username=uname)
        print(emp)
        request.session["eid"] = emp.id
        request.session["ename"] = emp.fullname
        return render(request, "userhome.html", {"eid": emp.id, "ename": emp.fullname})
    else:
        msg = "Login Failed"
        return render(request, "login.html", {"msg": msg})

def emplogout(request):
    return render(request,"login.html")

def userhome(request):
    eid=request.session["eid"]
    ename=request.session["ename"]
    return render(request,"userhome.html",{"eid":eid,"ename":ename})


def adminlogin(request):
    return render(request,"adminlogin.html")

def checkadminlogin(request):
    uname = request.POST["ausername"]
    pwd = request.POST["apassword"]

    flag = Admin.objects.filter(Q(username__exact=uname) & Q(password__exact=pwd))
    print(flag)

    if flag:
        admin = Admin.objects.get(username=uname)
        print(admin)
        request.session["auname"] = admin.username
        return render(request, "adminhome.html", {"auname": admin.username})
    else:
        msg = "Login Failed"
        return render(request, "adminlogin.html", {"msg": msg})


def adminhome(request):
    auname=request.session["auname"]
    return render(request,"adminhome.html",{"auname":auname})
def viewemployees(request):
    auname=request.session["auname"]
    emplist = Employee.objects.all()
    count = Employee.objects.count()
    return render(request,"viewcustomers.html",{"auname":auname,"emplist":emplist,"count":count})
def adminlogout(request):
    return render(request,"adminlogin.html")
def deleteemp(reequest,eid):
    Employee.objects.filter(id=eid).delete()
    return redirect("viewemps")
def profilepage(request):
    eid=request.session["eid"]
    ename=request.session["ename"]
    emp = Employee.objects.get(id=eid)
    return render(request,"profile.html",{"eid":eid,"ename":ename,"emp":emp})

def changepwd(request):
    eid=request.session["eid"]
    ename=request.session["ename"]
    return render(request,"changepwd.html",{"eid":eid,"ename":ename})

def updatepwd(request):
    eid=request.session["eid"]
    ename=request.session["ename"]

    opwd=request.POST["opwd"]
    npwd=request.POST["npwd"]

    flag = Employee.objects.filter(Q(id=eid) & Q(password=opwd))

    if flag:
        Employee.objects.filter(id=eid).update(password=npwd)
        msg = "Password Updated Successfully"
        return render(request, "changepwd.html", {"eid": eid, "ename": ename,"msg":msg})
    else:
        msg = "Old Password is Incorrect"
        return render(request, "changepwd.html", {"eid": eid, "ename": ename,"msg":msg})
def editprofile(request):
    eid = request.session["eid"]
    ename = request.session["ename"]
    return render(request, "editprofile.html", {"eid": eid, "ename": ename})
def edit(request):
    eid = request.session["eid"]
    ename = request.session["ename"]
    name = request.POST["epname"]
    phone = request.POST["phone"]
    location=request.POST["location"]
    flag = Employee.objects.filter(Q(id=eid))
    if flag:
        Employee.objects.filter(id=eid).update(fullname=name)
        Employee.objects.filter(id=eid).update(location=location)
        Employee.objects.filter(id=eid).update(contact=phone)
        msg="Profile Updated"
        emp = Employee.objects.get(id=eid)
        return render(request, "profile.html", {"eid": eid, "ename": ename, "msg": msg,"emp":emp})
    else:
        emp = Employee.objects.get(id=eid)
        msg="ERROR_____________ERROR"
        return render(request, "profile.html", {"eid": eid, "ename": ename, "msg": msg,"emp":emp})



def vieweproducts(request):

    eid=request.session["eid"]
    ename=request.session["ename"]

    productlist = Product.objects.all()

    return render(request,"vieweproducts.html",{"eid": eid, "ename": ename,"productlist":productlist})

def displayeproducts(request):

    eid=request.session["eid"]
    ename=request.session["ename"]

    pname = request.POST["pname"]
    print(pname)

    productlist = Product.objects.filter(name__icontains=pname)

    return render(request,"displayeproducts.html",{"eid": eid, "ename": ename,"productlist":productlist})
def addproduct(request):
    auname = request.session["auname"]
    form = ProductForm()
    if request.method == "POST":
        formdata = ProductForm(request.POST,request.FILES)
        if formdata.is_valid():
            formdata.save()
            msg="Product Added Successfully"
            return render(request, "addproduct.html", {"auname":auname,"productform": form,"msg":msg})
        else:
            msg = "Failed to Add Product"
            return render(request, "addproduct.html", {"auname":auname,"productform": form, "msg": msg})
    return render(request,"addproduct.html",{"auname":auname,"productform":form})

def viewaproducts(request):
    auname=request.session["auname"]
    productlist = Product.objects.all()
    count = Product.objects.count()
    return render(request,"viewaproducts.html",{"auname":auname,"productlist":productlist,"count":count})

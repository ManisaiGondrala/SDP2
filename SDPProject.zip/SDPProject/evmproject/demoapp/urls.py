from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns=[

path("",views.homepage,name="home"),
    path("userhome",views.userhome,name="userhome"),



path("index",views.indexpage,name="index"),
path("login",views.loginpage,name="login"),
    path("contactus",views.contactuspage,name="contactus"),
    path("about",views.aboutpage,name="about"),
    path("order",views.orderfunction,name="order"),
    path('checkemplogin',views.checkemplogin,name="checkemplogin"),
path('registration',views.registration,name="registration"),
path('emplogout',views.emplogout,name='emplogout'),
path('changepwd',views.changepwd,name="changepwd"),
    path('updatepwd', views.updatepwd, name="updatepwd"),
path('adminlogin',views.adminlogin,name='adminlogin'),
    path('checkadminlogin',views.checkadminlogin,name="checkadminlogin"),
    path('adminhome',views.adminhome,name="adminhome"),
path('viewemps',views.viewemployees,name="viewemps"),
path('adminlogout', views.adminlogout, name='adminlogout'),
path("deleteemp/<int:eid>",views.deleteemp,name="deleteemp"),
    path('profile', views.profilepage, name="profile"),
    path("addproduct", views.addproduct, name="addproduct"),
    path("viewaproducts", views.viewaproducts, name="viewaproducts"),
path("vieweproducts",views.vieweproducts,name="vieweproducts"),
    path("displayeproducts", views.displayeproducts, name="displayeproducts"),
    path("editprofile",views.editprofile,name="editprofile"),
path("edit",views.edit,name="edit"),
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
from django.contrib import admin
from .models import Admin,Employee,Product
# Register your models here.
admin.site.register(Employee)
admin.site.register(Admin)
admin.site.register(Product)

